#ifndef __LIBRARIES_H__
#define __LIBRARIES_H__

#include <iostream>
#include <cstdlib>
#include <vector> 
#include <fstream>
#include <string>
#include <map>
#include <cmath>  
#include <iomanip>
#define NOW "INDIFINITE_DATE"
#define DATE "0123456789/"
#define SIZE 11
#define INVALID -1
#define TIMENOW 10000000

#endif