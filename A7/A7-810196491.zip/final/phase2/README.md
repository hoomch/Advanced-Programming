AP HTTP
===
[![code style: LLVM](https://img.shields.io/badge/code_style-LLVM-brightgreen.svg?style=flat-square)](https://llvm.org/docs/CodingStandards.html)

**AP HTTP** is a simple web application framework for C++ based on simplified versions of [W++](http://konteck.github.io/wpp/), [HappyHTTP](http://scumways.com/happyhttp/happyhttp.html), and [cpp-netlib](http://cpp-netlib.org/). **AP HTTP** provides necessary functionalities for both server-side and client-side.
