<html>
<body>
<footer style="text-align: center">This is Footer</footer>
</body>
</html>