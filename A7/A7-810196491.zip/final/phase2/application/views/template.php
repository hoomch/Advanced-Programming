<html>
<head>
    <?php
    include 'templates/header.php';
    ?>
</head>

<body>
  <h3>This is body</h3>
<?php
include 'templates/footer.php';
?>
</body>
</html>

