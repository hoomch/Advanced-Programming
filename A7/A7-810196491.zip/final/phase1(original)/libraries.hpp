#ifndef __LIBRARIES_H__
#define __LIBRARIES_H__

#include <iostream>
#include <cstdlib>
#include <vector> 
#include <fstream>
#include <string>
#include <map>
#include <cmath>  
#include <iomanip>
#include <ctime> 
#define INVALID -1

using namespace std;

#endif