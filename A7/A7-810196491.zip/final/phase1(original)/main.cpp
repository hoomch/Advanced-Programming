#include "jeekjeek.hpp"
#include "connectors.hpp"
int main(){
	JeekJeek jeekJeeker;
	//JeekJeek j;
	processProgram(jeekJeeker);
	/*User u("a" , "A" , "1234");
	Jeek jee("jeek Text ! :)" , "gav" , "khar" , "b");
	j.signUp("ali" , "Ali" , "12345678");
	j.logIn("ali" , "12345678");
	j.addNewJeek(jee);
	j.showJeek("jeekId1");
	j.searchUser("ali");
	/*j.addComment("jeekId1","kheyli khari");
	j.addComment("jeekId1","kheyl khari");
	j.addReplyToComment("commentId2", "khodeti");
	//j.showComment(1);
	//j.showReply("replyId1");
	j.addReplyToReply("replyId1", "bazam khari");
	j.showReply("replyId1");
	j.addReplyToReply("replyId2" , "sds");
	j.showReply("replyId1");
	j.showReply("replyId2");
	j.showReply("replyId3");
	j.signUp("fsdf" , "sdli" , "1234d78");
	//j.showReply(1);
	//j.showComment(1);
	j.reJeek("jeekId1");
	//j.showJeek(2);
	j.like("jeekId1");
	//j.dislike(1);
	//j.showJeek(1);
	j.follow("fsdf");
	j.follow("ali");
	j.unfollow("ali");
	j.unfollow("fsdf");
	j.unfollow("ali");
	j.unfollow("fsds");*/
	
}