#ifndef __FUNCTION_H__
#define __FUNCTION_H__

#include "libraries.hpp"

string int_to_string(int input);

#endif