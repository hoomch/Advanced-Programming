#ifndef __JEEKJEEK_H__
#define __JEEKJEEK_H__

#include "user.hpp"
#include "reply.hpp"
#include "functions.hpp"
#include "exceptions.hpp"

class JeekJeek{
public:
	JeekJeek();
	void signUp(string _username , string _displayName , string _password);
		bool isUsernameUnique(string _username);
	void logIn(string _username , string _password);
		int findUser(string _username);
	void logOut();
	void addNewJeek(Jeek newJeek);
		void notifyMentionedUsers(Jeek newJeek);
	void showJeek(string _jeekId);
		int findUserOnJeekId(string _jeekId);
	void searchUser(string _username);
	void searchHashTag(string hash_tag);
	void addComment(string _jeekId , string _commentText);
	void addReplyToComment(string _commentId , string _replyText);
		Comment* getComment(string _commentId);
		int findUserOnCommentId(string _commentId);
	void addReplyToReply(string _replyId , string _replyText);	
		int findReply(string _replyId);
		int findUserOnReplyId(string _replyId);
	void reJeek(string _jeekId);
	void showComment(string _commentId);
	void showReply(string _replyId);
	void like(string _jeekId);
	void dislike(string _jeekId);
	void follow(string _username);
		User* getUserOnName(string _username);
	void unfollow(string _username);
	void addNotification(string newNotification , string _username);
	void showNotifications();		

private:
	vector <User> users;
	User *userIn;
	vector <Reply> replies;
	bool is_user_in;
	int numOfJeeks;
	int numOfComments;
	int numOfReplies;
};

#endif