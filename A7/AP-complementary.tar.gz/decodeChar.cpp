#include <iostream>
#include <bitset>
using namespace std;

int main() {
	char c;
	while(cin >> c)
		cout << "c is equal to: " << c << "  int(c)=" << int(c) << "  binary_of_c=" << bitset<8>(c) << endl;
	return 0;
}
