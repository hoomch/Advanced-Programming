#!/bin/bash

g++ printChar.cpp -Wall -o printChar
g++ decodeChar.cpp -Wall -o decodeChar

./printChar | ./decodeChar
