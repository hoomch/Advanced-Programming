#include <iostream>
#include <bitset>
using namespace std;
typedef long long ll;

int main() {
	ios::sync_with_stdio(false);
	for (int i = 0; i < 256; ++i)
		cout << char(i) << endl;
	return 0;
}
